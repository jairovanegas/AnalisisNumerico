methods.horner <- function(coeficientes, x) {
    acumulado <- coeficientes[1]
    q <- c(acumulado)
    multiplicaciones <- 0
    for (i in 2:length(coeficientes)) {
        acumulado <- (acumulado * x) + coeficientes[i]
        if (i < length(coeficientes)) {
            q <- c(q, acumulado)
        }
        multiplicaciones <- multiplicaciones + 1
    }
    return(list(
        "iter" = multiplicaciones,
        "res" = acumulado,
        "q" = mpfr2array(q, dim = length(q))
    ))
}

methods.hornerD1 <- function(coeficientes, x) {
    #Evaluamos el polinomio q en x con lo que tenemos la derivada en x
    q <- methods.horner(coeficientes, x)$q
    return(methods.horner(q, x))
}

methods.hornerD2 <- function(coeficientes, x) {
    #Vector con los nuevos coeficientes derivados
    coeficientesD <- c()
    #Serie con los grados del polinomio de mayor a menor
    serie <- seq(length(coeficientes) - 1, 1, -1)
    #Vamos hasta el penultimo coeficiente ya que el termino independiente queda en 0
    for (i in 1:length(coeficientes) - 1) {
        #Se multiplica el coeficiente por su grado
        coeficientesD <- c(coeficientesD, coeficientes[i] * serie[i])
    }
    #Debido a la libreria RMPF se convierten los vectores en listas, con esto los volvemos a convertir en vector
    coeficientesD <- mpfr2array(coeficientesD, dim = length(coeficientesD))
    #Evaluamos la derivada con lo que obtenemos el polinomio q con el que evaluamos la derivada de la derivada
    q <- methods.horner(coeficientesD, x)$q
    return(methods.horner(q, x))
}

methods.laguerre <- function(coeficientes, x, tolerancia) {
    n <- length(coeficientes) - 1
    iteraciones <- 0
    i <- 0
    p.all <- methods.horner(coeficientes, x)
    p <- p.all$res
    iteraciones <- iteraciones + p.all$iter
    pD1.all <- methods.hornerD1(coeficientes, x)
    pD1 <- pD1.all$res
    iteraciones <- iteraciones + pD1.all$iter
    pD2.all <- methods.hornerD2(coeficientes, x)
    pD2 <- pD2.all$res
    iteraciones <- iteraciones + pD2.all$iter
    G <- pD1 / p
    H <- G^2 - (pD2 / p)
    raiz <- sqrt((n - 1) * ((n * H) - (G^2)))
    x2 <- 0
    if (G + raiz > G - raiz) {
        x2 <- x - (n / (G + raiz))
    } else {
        x2 <- x - (n / (G + raiz))
    }
    prev <- x
    x <- x2
    i <- i + 1
    print(x)
    while (abs(x - prev) > tolerancia) {
        p.all <- methods.horner(coeficientes, x)
        p <- p.all$res
        iteraciones <- iteraciones + p.all$iter
        pD1.all <- methods.hornerD1(coeficientes, x)
        pD1 <- pD1.all$res
        iteraciones <- iteraciones + pD1.all$iter
        pD2.all <- methods.hornerD2(coeficientes, x)
        pD2 <- pD2.all$res
        iteraciones <- iteraciones + pD2.all$iter
        G <- pD1 / p
        H <- G^2 - (pD2 / p)
        raiz <- sqrt((n - 1) * ((n * H) - (G^2)))
        x2 <- 0
        if (G + raiz > G - raiz) {
            x2 <- x - (n / (G + raiz))
        } else {
            x2 <- x - (n / (G + raiz))
        }
        if(is.na(x2)){
            break;
        }
        prev <- x
        x <- x2
        i <- i + 1
        print(x)
    }
    return(list(
        "res" = x,
        "iterTotal" = iteraciones,
        "iterMetodo" = i
    ))
}

methods.newton_horner <- function(coeficientes, x, tolerancia) {
    i <- 0
    iteraciones <- 0
    p.all <- methods.horner(coeficientes, x)
    p <- p.all$res
    iteraciones <- iteraciones + p.all$iter
    pD1.all <- methods.hornerD1(coeficientes, x)
    pD1 <- pD1.all$res
    iteraciones <- iteraciones + pD1.all$iter
    x2 <- x - (p / pD1)
    prev <- x
    x <- x2
    i <- i + 1
    while (abs(x - prev) > tolerancia) {
        p.all <- methods.horner(coeficientes, x)
        p <- p.all$res
        iteraciones <- iteraciones + p.all$iter
        pD1.all <- methods.hornerD1(coeficientes, x)
        pD1 <- pD1.all$res
        iteraciones <- iteraciones + pD1.all$iter
        x2 <- x - (p / pD1)
        prev <- x
        x <- x2
        i <- i + 1
    }
    return(list(
        "res" = x,
        "iterTotal" = iteraciones,
        "iterMetodo" = i
    ))
}