library("Rmpfr")
setwd("C:\Users\Luisa\Desktop\OCTAVO\AN�LISIS NUM�RICO\Reto 1\reto1")
source("./methods.R")
source("./utils.R")

polinomios.generador <- function(grado) {
    coeficientes <- runif(grado, min = -1000, max = 1000)
    coeficientes <- ceiling(coeficientes)
    return(coeficientes)
}

polinomios.presentador <- function(polinomio) {
    polinomio_string <- "f -> "
    i <- length(polinomio)-1
    for(p in polinomio){
        #print(polinomio[j])
        if(p > 0){
            polinomio_string <- paste(polinomio_string, "+", abs(p), "*x^", i, " ", sep = "")
        }else{
            polinomio_string <- paste(polinomio_string, "-", abs(p), "*x^", i, " ", sep = "")
        }
        i <- i-1
    }
    #polinomio_string <- paste(polinomio_string, polinomio[length(polinomio)], sep = "")
    return(polinomio_string)
}

experimento <- function() {
    #coeficientes <- c(1, -8, -72, 382, 727, -2310)
    coeficientes <- c(1, -5, -9, 155, -250)
    x <- runif(1, min = -50, max = 50)
    tolerancia <- toleranciaFactory(-16)
    #coeficientes <- polinomios.generador(2)
    x <- mpfr(2, tolerancia$bits)
    print(polinomios.presentador(coeficientes))
    coeficientes <- sapply(coeficientes, mpfr, precBits = tolerancia$bits)
    coeficientes <- mpfr2array(coeficientes, dim = length(coeficientes))
    print(methods.laguerre(coeficientes, x, tolerancia$tol)$res)
    print(methods.newton_horner(coeficientes, x, tolerancia$tol)$res)
}

experimento()